<?php
/**
 * Scan Pro Child Theme — functions.php
 *
 * NOTA: Para ativar alemão como idioma padrão do WordPress,
 * adicionar no wp-config.php:
 *   define('WPLANG', 'de_DE');
 *
 * Para adicionar francês depois:
 * 1. Instalar o plugin Polylang (gratuito)
 * 2. Em Polylang > Idiomas, adicionar DE e FR
 * 3. Duplicar as páginas e traduzir os conteúdos para FR
 * 4. Os textos dos templates PHP já usam __() e estarão prontos para tradução
 */

// Enfileirar estilos do tema pai + filho e scripts
add_action( 'wp_enqueue_scripts', function () {

    // Estilos do tema pai
    wp_enqueue_style(
        'hello-elementor-style',
        get_template_directory_uri() . '/style.css'
    );

    // Google Fonts
    wp_enqueue_style(
        'scanpro-fonts',
        'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;700&family=Roboto+Slab:wght@400;600&family=Inter:wght@400;500;600&display=swap',
        [],
        null
    );

    // CSS principal do tema filho
    wp_enqueue_style(
        'scanpro-main',
        get_stylesheet_directory_uri() . '/assets/css/main.css',
        [ 'scanpro-fonts' ],
        '2.2.0'
    );

    // CSS do header
    wp_enqueue_style(
        'scanpro-header',
        get_stylesheet_directory_uri() . '/assets/css/header.css',
        [ 'scanpro-main' ],
        '2.8.0'
    );

    // CSS do footer
    wp_enqueue_style(
        'scanpro-footer',
        get_stylesheet_directory_uri() . '/assets/css/footer.css',
        [ 'scanpro-main' ],
        '1.1.0'
    );

    // CSS da home
    if ( is_front_page() ) {
        wp_enqueue_style(
            'scanpro-home',
            get_stylesheet_directory_uri() . '/assets/css/home.css',
            [ 'scanpro-main' ],
            '3.2.0'
        );
    }

    // CSS Einsatzbereiche — páginas de áreas de aplicação e seção da home
    wp_enqueue_style(
        'scanpro-einsatzbereiche',
        get_stylesheet_directory_uri() . '/assets/css/einsatzbereiche.css',
        [ 'scanpro-main' ],
        '2.0.0'
    );

    // CSS Wissen
    wp_enqueue_style(
        'scanpro-wissen',
        get_stylesheet_directory_uri() . '/assets/css/wissen.css',
        [ 'scanpro-main' ],
        '1.0.1'
    );

    // CSS Referenzen
    wp_enqueue_style(
        'scanpro-referenzen',
        get_stylesheet_directory_uri() . '/assets/css/referenzen.css',
        [ 'scanpro-main' ],
        '1.1.0'
    );

    // CSS do WooCommerce — carrega após os estilos do WooCommerce para garantir precedência
    if ( class_exists( 'WooCommerce' ) ) {
        wp_enqueue_style(
            'scanpro-woocommerce',
            get_stylesheet_directory_uri() . '/assets/css/woocommerce.css',
            [ 'scanpro-main', 'woocommerce-general', 'woocommerce-layout', 'woocommerce-smallscreen' ],
            '1.6.0'
        );
    }

    // Script principal
    wp_enqueue_script(
        'scanpro-main',
        get_stylesheet_directory_uri() . '/assets/js/main.js',
        [ 'jquery' ],
        '1.5.0',
        true
    );

    // Formulário de contacto (Web3Forms) — apenas na página Kontakt
    if ( is_page_template( 'page-kontakt.php' ) || is_page( 'kontakt' ) ) {
        wp_enqueue_script(
            'scanpro-kontakt',
            get_stylesheet_directory_uri() . '/assets/js/kontakt.js',
            [],
            '1.0.0',
            true
        );

        wp_localize_script( 'scanpro-kontakt', 'scanproKontakt', [
            'sending' => __( 'Wird gesendet…', 'scanpro-child' ),
            'success' => __( 'Vielen Dank! Ihre Anfrage wurde erfolgreich gesendet. Wir melden uns so bald wie möglich.', 'scanpro-child' ),
            'error'   => __( 'Es ist ein Fehler aufgetreten. Bitte versuchen Sie es später erneut oder kontaktieren Sie uns per Telefon.', 'scanpro-child' ),
        ] );
    }

} );

// Configurações do tema e suporte a features
//
// NOTA (WordPress 6.7+): nada aqui pode chamar __() ou carregar o textdomain.
// Este gancho corre antes do 'init', e desde a versão 6.7 o WordPress descarta
// traduções pedidas nessa fase — o texto fica no idioma original, em silêncio.
// Tudo o que envolva tradução foi movido para o 'init', mais abaixo.
add_action( 'after_setup_theme', function () {

    // Suporte a WooCommerce
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    // Suporte a imagens em destaque
    add_theme_support( 'post-thumbnails' );
} );

// Traduções e menus — no 'init', nunca antes.
add_action( 'init', function () {

    // O WordPress carrega as traduções do tema automaticamente desde a 4.6.
    // A chamada explícita fica como reforço, agora no momento correto.
    load_child_theme_textdomain(
        'scanpro-child',
        get_stylesheet_directory() . '/languages'
    );

    // Suporte a menus de navegação
    register_nav_menus( [
        'primary' => __( 'Hauptmenü', 'scanpro-child' ),
        'footer'  => __( 'Fusszeile', 'scanpro-child' ),
    ] );
} );

// Remover o prefixo "Categoria:" dos títulos de arquivo WooCommerce
add_filter( 'woocommerce_page_title', function ( $title ) {
    return $title;
} );

// Fixar 3 colunas no loop de produtos
add_filter( 'loop_shop_columns', function () { return 3; } );

// Remover o breadcrumb padrão do WooCommerce (o template usa o nosso próprio)
add_action( 'init', function () {
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
} );

// Produtos não são precificados no site — remover exibição de preço
// e do badge "em oferta" (percentual de desconto) no loop e no produto individual
add_action( 'init', function () {
    remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
    remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
    remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
} );

// Remover opções de ordenação por preço no dropdown da loja, já que não há preços
add_filter( 'woocommerce_catalog_orderby', function ( $options ) {
    unset( $options['price'], $options['price-desc'] );
    return $options;
} );
add_filter( 'woocommerce_default_catalog_orderby_options', function ( $options ) {
    unset( $options['price'], $options['price-desc'] );
    return $options;
} );

// Sidebar de navegação da seção Wissen
if ( ! function_exists( 'scanpro_wissen_sidebar' ) ) {
    function scanpro_wissen_sidebar() {
        $pages = [
            [ 'label' => 'CO₂',                      'slug' => 'wissen/co2' ],
            [ 'label' => 'FAQ',                       'slug' => 'wissen/faq' ],
            [ 'label' => 'Blog',                      'slug' => 'wissen/blog' ],
            [ 'label' => 'Regulierungen',             'slug' => 'wissen/regulierungen' ],
            [ 'label' => 'Regelung von Luftmengen',   'slug' => 'wissen/regelung-von-luftmengen' ],
        ];
        $current = get_page_uri();
        ?>
        <aside class="wissen-sidebar">
          <h4><?php _e( 'Wissen', 'scanpro-child' ); ?></h4>
          <ul class="wissen-nav">
            <?php foreach ( $pages as $p ) :
              $page   = get_page_by_path( $p['slug'] );
              $url    = $page ? get_permalink( $page->ID ) : '#';
              $active = ( $current === $p['slug'] ) ? 'active' : '';
            ?>
              <li class="<?php echo esc_attr( $active ); ?>">
                <a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $p['label'] ); ?></a>
              </li>
            <?php endforeach; ?>
          </ul>
        </aside>
        <?php
    }
}

// Função helper para gerar URLs de categorias de produto de forma consistente
if ( ! function_exists( 'scanpro_product_cat_url' ) ) {
    function scanpro_product_cat_url( string $slug ): string {
        return get_term_link( $slug, 'product_cat' ) ?: home_url( '/produktkategorie/' . $slug );
    }
}

// Conteúdo HTML das subpáginas Einsatzbereiche — detectado por slug
if ( ! function_exists( 'scanpro_get_einsatzbereich_content' ) ) {
    function scanpro_get_einsatzbereich_content( string $slug ): string {

        $contents = [];

        // — WOHNEN ————————————————————————————————————
        $contents['wohnen'] = '
<div class="eb-intro">
  <h2>' . __( 'Frische Luft, wo das Leben stattfindet', 'scanpro-child' ) . '</h2>
  <p>' . __( 'Ob Einfamilienhaus, Mehrfamilienhaus oder Wohnanlage — dort, wo Menschen wohnen, schlafen und leben, ist Luftqualität keine Nebensache. Viele Neubauten und energetisch sanierte Gebäude sind heute so dicht, dass eine natürliche Lüftung über Fenster und Ritzen kaum mehr möglich ist. Die Folge: erhöhte CO₂-Konzentrationen, Feuchtigkeit, Schimmelgefahr und ein spürbares Nachlassen von Komfort und Wohlbefinden.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Eine kontrollierte Wohnraumlüftung sorgt dafür, dass verbrauchte Luft zuverlässig abgeführt und gleichzeitig frische Aussenluft zugeführt wird — und das energieeffizient, dank integrierter Wärmerückgewinnung. So bleibt Wärme im Gebäude, ohne auf Frischluft zu verzichten.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-anforderungen">
  <h3>' . __( 'Technische Anforderungen an die Wohnraumlüftung', 'scanpro-child' ) . '</h3>
  <p>' . __( 'Ein normgerechtes Lüftungskonzept für Wohngebäude sollte folgende Zielwerte sicherstellen:', 'scanpro-child' ) . '</p>
  <ul class="eb-list">
    <li>' . __( 'CO₂-Konzentration im Mittelwert ≤ 1.000 ppm während der Nutzung', 'scanpro-child' ) . '</li>
    <li>' . __( 'Raumtemperatur 20 bis 26 °C', 'scanpro-child' ) . '</li>
    <li>' . __( 'Relative Luftfeuchte 30 bis 60 %', 'scanpro-child' ) . '</li>
    <li>' . __( 'Mittlere Luftgeschwindigkeit ≤ 0,15 m/s — kein Zugluftgefühl', 'scanpro-child' ) . '</li>
    <li>' . __( 'Schalldruckpegel ≤ 30 dB(A) in Schlaf- und Wohnräumen', 'scanpro-child' ) . '</li>
    <li>' . __( 'Wärmerückgewinnungsgrad ≥ 75 % gemäss SIA 382/1', 'scanpro-child' ) . '</li>
  </ul>
</div>

<div class="eb-loesung">
  <h3>' . __( 'Die Scan-Pro Lösung für Wohngebäude', 'scanpro-child' ) . '</h3>
  <p>' . __( 'Mit unserem Sortiment an zentralen und dezentralen Lüftungsgeräten — unter anderem aus dem Hause EXHAUSTO und Aldes — decken wir alle Anforderungen moderner Wohnraumlüftung ab. Unsere Geräte mit Gegenstrom- oder Rotationstauscher erreichen Wärmerückgewinnungsgrade von bis zu 95 % und arbeiten dabei ausgesprochen leise.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Ob Neubau oder Sanierung, Einfamilienhaus oder grössere Überbauung — wir beraten Sie bei der Wahl des richtigen Systems und unterstützen Planer und Installateure mit technischen Unterlagen, Auslegungshilfen und direktem Fachsupport.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-specs-grid">
  <div class="eb-spec-card">
    <h4>' . __( 'Volumenstrom', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Aussenluftvolumenstrom ≥ 30 m³/h pro Person', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Schall', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Schalldruckpegel ≤ 30 dB(A) in Schlafräumen', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Wärmerückgewinnung', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Wirkungsgrad bis zu 95 % — Energie sparen ohne Komfortverlust', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Filter', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Aussenluftfilter mindestens ePM1 50 % gemäss ISO 16890', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Regelung', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Bedarfsorientierte Steuerung nach CO₂, Feuchte oder Präsenz', 'scanpro-child' ) . '</p>
  </div>
</div>';

        // — GEWERBE ————————————————————————————————————
        $contents['gewerbe'] = '
<div class="eb-intro">
  <h2>' . __( 'Raumklima, das Produktivität fördert', 'scanpro-child' ) . '</h2>
  <p>' . __( 'Wussten Sie, dass schlechte Raumluft die Leistungsfähigkeit von Mitarbeitenden um bis zu 15 % senken kann? In Büros, Verwaltungsgebäuden und Gewerbeflächen ist ein durchdachtes Lüftungskonzept daher keine Kostenstelle — sondern eine Investition in Produktivität, Gesundheit und Wohlbefinden.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Moderne Bürogebäude stellen besondere Anforderungen an die Lüftungstechnik: Viele Personen auf engem Raum, hohe interne Wärmelasten durch Technik und Beleuchtung sowie immer dichtere Gebäudehüllen machen eine mechanische Be- und Entlüftung unumgänglich. Eine bedarfsgeregelte Anlage sorgt dafür, dass Frischluft genau dann zugeführt wird, wenn sie gebraucht wird — energieeffizient und ohne unnötige Geräusche.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-anforderungen">
  <h3>' . __( 'Technische Anforderungen an die Büro- und Gewerbelüftung', 'scanpro-child' ) . '</h3>
  <p>' . __( 'Ein normgerechtes raumlufttechnisches Konzept sollte folgende Zielwerte sicherstellen:', 'scanpro-child' ) . '</p>
  <ul class="eb-list">
    <li>' . __( 'CO₂-Konzentration im Mittelwert ≤ 1.000 ppm über die Nutzungsdauer', 'scanpro-child' ) . '</li>
    <li>' . __( 'Raumtemperatur 20 bis 26 °C', 'scanpro-child' ) . '</li>
    <li>' . __( 'Relative Raumluftfeuchte 30 bis 60 %', 'scanpro-child' ) . '</li>
    <li>' . __( 'Mittlere Luftgeschwindigkeit ≤ 0,15 m/s', 'scanpro-child' ) . '</li>
    <li>' . __( 'Schalldruckpegel ≤ 35 dB(A) in Einzel- und Besprechungsräumen, ≤ 45 dB(A) in Grossraumbüros', 'scanpro-child' ) . '</li>
  </ul>
</div>

<div class="eb-loesung">
  <h3>' . __( 'Die Scan-Pro Lösung für Gewerbe und Büros', 'scanpro-child' ) . '</h3>
  <p>' . __( 'Unser breites Sortiment an zentralen und semi-zentralen Lüftungsgeräten ermöglicht massgeschneiderte Lösungen für Bürogebäude jeder Grösse — vom Kleinbüro bis zum mehrgeschossigen Verwaltungsbau. Wärmerückgewinnung ist dabei selbstverständlich: Mit Wirkungsgraden von bis zu 95 % senken unsere Geräte die Betriebskosten spürbar.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Fachplaner und Installateure unterstützen wir mit technischen Unterlagen, Auslegungsprogrammen und persönlicher Beratung — von der Konzeption bis zur Inbetriebnahme.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-specs-grid">
  <div class="eb-spec-card">
    <h4>' . __( 'Volumenstrom', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Aussenluftvolumenstrom > 25 m³/h pro Person im Raum', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Schall', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Schallleistungspegel ≤ 35 dB(A) für Büro- und Besprechungsräume', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Energieeffizienz', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Verpflichtender Einsatz von Wärmerückgewinnung gemäss SIA 382/1', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Filter', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Aussenluftfilter mindestens ePM1 50 % gemäss ISO 16890', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Regelung', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Bedarfsorientierte Einzelraumregelung nach CO₂ und Belegung', 'scanpro-child' ) . '</p>
  </div>
</div>';

        // — INDUSTRIE ————————————————————————————————————
        $contents['industrie'] = '
<div class="eb-intro">
  <h2>' . __( 'Lüftungstechnik für anspruchsvolle Umgebungen', 'scanpro-child' ) . '</h2>
  <p>' . __( 'In Produktionshallen, Werkstätten und Industriebetrieben entstehen täglich Herausforderungen, die gewöhnliche Lüftungsanlagen schnell an ihre Grenzen bringen: Wärme durch Maschinen und Prozesse, Staub, Dämpfe, Schadstoffe und ein hoher Personenverkehr verlangen nach robusten, leistungsstarken Lüftungslösungen.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Eine durchdachte Industrielüftung schützt die Gesundheit der Mitarbeitenden, verlängert die Lebensdauer von Maschinen und Gebäudestrukturen und hilft, Energiekosten durch intelligente Wärmerückgewinnung zu senken. Dabei muss sie den rauen Bedingungen des industriellen Alltags standhalten — zuverlässig, wartungsarm und effizient.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-anforderungen">
  <h3>' . __( 'Technische Anforderungen an die Industrielüftung', 'scanpro-child' ) . '</h3>
  <p>' . __( 'Die Auslegung richtet sich nach den spezifischen Prozessen und Emissionen im Betrieb. Folgende Richtwerte gelten als Grundlage:', 'scanpro-child' ) . '</p>
  <ul class="eb-list">
    <li>' . __( 'Ausreichende Abfuhr von Wärme, Feuchtigkeit, Staub und prozessbedingten Schadstoffen', 'scanpro-child' ) . '</li>
    <li>' . __( 'Raumtemperatur in Arbeitsbereichen: mindestens 15 °C, maximal 26 °C', 'scanpro-child' ) . '</li>
    <li>' . __( 'CO₂-Konzentration ≤ 1.000 ppm in dauerhaft besetzten Zonen', 'scanpro-child' ) . '</li>
    <li>' . __( 'Filterklasse je nach Prozess und Schadstoffart: mindestens ePM10 50 %', 'scanpro-child' ) . '</li>
    <li>' . __( 'Schalldruckpegel nach Arbeitsschutzanforderungen, je nach Nutzungszone', 'scanpro-child' ) . '</li>
    <li>' . __( 'Wärmerückgewinnung wo prozessbedingt möglich — Einsparungen bis zu 80 %', 'scanpro-child' ) . '</li>
  </ul>
</div>

<div class="eb-loesung">
  <h3>' . __( 'Die Scan-Pro Lösung für Industrie und Gewerbe', 'scanpro-child' ) . '</h3>
  <p>' . __( 'Wir liefern leistungsstarke Ventilatoren, Dachventilatoren, Abluftsysteme und komplette raumlufttechnische Anlagen, die auch unter industriellen Bedingungen zuverlässig funktionieren. Unser Sortiment umfasst Geräte für die direkte Prozessabluft ebenso wie bedarfsgeregelte Gesamtlösungen für grosse Hallenflächen.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Dank unserer langjährigen Erfahrung in der Schweizer Industrie kennen wir die besonderen Anforderungen verschiedener Branchen — von der Lebensmittelverarbeitung über den Maschinenbau bis zur Werkstatt. Wir entwickeln individuelle Lösungsansätze und stehen Planern sowie Betreibern als technischer Partner zur Seite.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-specs-grid">
  <div class="eb-spec-card">
    <h4>' . __( 'Volumenstrom', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Individuell nach Prozess, Hallengrösse und Personenbelegung', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Robustheit', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Geräte für hohe Betriebsstunden, Staub und aggressive Umgebungen', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Wärmerückgewinnung', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Nutzung von Prozesswärme zur Senkung der Heizkosten', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Filter', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Filterklasse je nach Schadstoff und Prozessanforderung wählbar', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Regelung', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Bedarfsgerechte Steuerung nach Belegung, Temperatur und Schadstoffbelastung', 'scanpro-child' ) . '</p>
  </div>
</div>';

        // — BILDUNGSEINRICHTUNGEN ————————————————————————————————————
        $contents['bildungseinrichtungen'] = '
<div class="eb-intro">
  <h2>' . __( 'Gute Luft ist die Grundlage für gutes Lernen', 'scanpro-child' ) . '</h2>
  <p>' . __( 'Klassenräume, Kitas, Aulas und Hochschulgebäude sind Orte, an denen sich viele Menschen auf engem Raum aufhalten. Ohne ausreichenden Luftwechsel steigt der CO₂-Gehalt rasch auf Werte, die Konzentration, Merkfähigkeit und Wohlbefinden spürbar beeinträchtigen. Studien belegen: Ab 1.000 ppm sinkt die kognitive Leistungsfähigkeit messbar.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Gleichzeitig stellen Bildungseinrichtungen besondere Anforderungen an Lärm und Energieeffizienz: Lüftungsgeräte müssen im Unterrichtsbetrieb leise arbeiten, bedarfsgerecht reagieren und in Sanierungen wie Neubauten gleichermassen integrierbar sein. Fensterlüftung allein — abhängig von Aussentemperatur, Lärm und Wetter — reicht dafür längst nicht mehr aus.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-anforderungen">
  <h3>' . __( 'Technische Anforderungen an die Schul- und Kitaslüftung', 'scanpro-child' ) . '</h3>
  <p>' . __( 'Die Auslegung richtet sich nach DIN EN 16798 sowie den schweizerischen Normen SIA 382/1 und SWKI VA104-01. Folgende Zielwerte gelten als massgeblich:', 'scanpro-child' ) . '</p>
  <ul class="eb-list">
    <li>' . __( 'CO₂-Mittelwert ≤ 1.000 ppm während der Nutzungszeit', 'scanpro-child' ) . '</li>
    <li>' . __( 'Raumtemperatur 20 bis 26 °C', 'scanpro-child' ) . '</li>
    <li>' . __( 'Relative Luftfeuchte 30 bis 60 %', 'scanpro-child' ) . '</li>
    <li>' . __( 'Mittlere Luftgeschwindigkeit ≤ 0,15 m/s — kein störendes Zugluftgefühl', 'scanpro-child' ) . '</li>
    <li>' . __( 'Schalldruckpegel ≤ 35 dB(A) in Unterrichtsräumen, ≤ 40 dB(A) in Sporthallen', 'scanpro-child' ) . '</li>
    <li>' . __( 'Aussenluftvolumenstrom > 25 m³/h pro Person', 'scanpro-child' ) . '</li>
  </ul>
</div>

<div class="eb-loesung">
  <h3>' . __( 'Die Scan-Pro Lösung für Schulen und Bildungsbauten', 'scanpro-child' ) . '</h3>
  <p>' . __( 'Wir bieten zentrale, semi-zentrale und dezentrale Lüftungslösungen für alle Bereiche einer Bildungseinrichtung — vom Klassenraum über die Mensa bis zur Sporthalle und den Sanitärbereichen. Unsere Geräte mit hocheffizienter Wärmerückgewinnung arbeiten leise, zuverlässig und lassen sich bedarfsgerecht nach CO₂, Belegung oder Zeitprogramm steuern.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Für Neubauten wie für Sanierungen stehen verschiedene Systemvarianten zur Verfügung. Planern stellen wir technische Unterlagen, Auslegungshilfen und Produktdatenblätter zur Verfügung — und beraten Sie gerne direkt bei der Systemwahl.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-specs-grid">
  <div class="eb-spec-card">
    <h4>' . __( 'Volumenstrom', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Aussenluftvolumenstrom > 25 m³/h pro Person im Raum', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Schall', 'scanpro-child' ) . '</h4>
    <p>' . __( '≤ 35 dB(A) in Unterrichtsräumen, ≤ 40 dB(A) in Sporthallen', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Energieeffizienz', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Wärmerückgewinnung verpflichtend — Wirkungsgrad bis zu 95 %', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Filter', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Aussenluftfilter mindestens ePM1 50 % gemäss ISO 16890', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Regelung', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Bedarfsorientierte Einzelraumregelung nach CO₂, Feuchte oder Belegungsplan', 'scanpro-child' ) . '</p>
  </div>
</div>';

        // — GASTRONOMIE ————————————————————————————————————
        $contents['gastronomie'] = '
<div class="eb-intro">
  <h2>' . __( 'Küche und Gastraum — zwei Anforderungen, eine Lösung', 'scanpro-child' ) . '</h2>
  <p>' . __( 'Wer in einer professionellen Küche arbeitet, weiss: Wenn mehrere Herdplatten laufen und der Ofen auf Hochtouren ist, verwandelt sich der Raum schnell in ein unangenehmes Arbeitsumfeld aus Hitze, Gerüchen und Wasserdampf. Was in der Küche entsteht, darf den Gastraum nicht erreichen — und doch liegen beide oft nur wenige Meter voneinander entfernt.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Die Gastronomie steht täglich vor dieser doppelten Herausforderung: In der Küche braucht es eine leistungsstarke Ablufttechnik, die Hitze, Fett und Gerüche effektiv abführt. Im Gastraum hingegen sollen die Gäste bei angenehmer Temperatur und frischer Luft entspannen — unabhängig davon, wie viele Personen sich im Raum befinden. Eine optimal ausgelegte Lüftungsanlage schafft diese Balance und wird damit zu einem entscheidenden Faktor für Ihren Betriebserfolg.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-anforderungen">
  <h3>' . __( 'Technische Anforderungen — Küche und Gastraum', 'scanpro-child' ) . '</h3>

  <h4>' . __( 'Anforderungen für die Küche', 'scanpro-child' ) . '</h4>
  <ul class="eb-list">
    <li>' . __( 'Wirksame Abfuhr von Feuchtigkeit, Wärme, Fett und Verbrennungsprodukten', 'scanpro-child' ) . '</li>
    <li>' . __( 'Raumtemperatur mindestens 18 °C, maximal 26 °C', 'scanpro-child' ) . '</li>
    <li>' . __( 'Relative Luftfeuchte in der Aufenthaltszone: 55 bis 80 %', 'scanpro-child' ) . '</li>
    <li>' . __( 'Aussenluft darf die Lebensmittelqualität nicht beeinträchtigen', 'scanpro-child' ) . '</li>
    <li>' . __( 'Schalldruckpegel ≤ 60 dB(A)', 'scanpro-child' ) . '</li>
  </ul>

  <h4 style="margin-top: 24px;">' . __( 'Anforderungen für den Gastraum', 'scanpro-child' ) . '</h4>
  <ul class="eb-list">
    <li>' . __( 'CO₂-Konzentration im Mittelwert ≤ 1.000 ppm', 'scanpro-child' ) . '</li>
    <li>' . __( 'Raumtemperatur 20 bis 26 °C', 'scanpro-child' ) . '</li>
    <li>' . __( 'Relative Luftfeuchte 30 bis 60 %', 'scanpro-child' ) . '</li>
    <li>' . __( 'Mittlere Luftgeschwindigkeit ≤ 0,15 m/s — kein Zugluftgefühl für Gäste', 'scanpro-child' ) . '</li>
    <li>' . __( 'Schalldruckpegel ≤ 50 dB(A)', 'scanpro-child' ) . '</li>
  </ul>
</div>

<div class="eb-loesung">
  <h3>' . __( 'Die Scan-Pro Lösung für die Gastronomie', 'scanpro-child' ) . '</h3>
  <p>' . __( 'Mit unserem Sortiment aus leistungsstarken Küchenabluftgeräten, zentralen Lüftungsanlagen und bedarfsgeregelten Systemen für den Gastraum bieten wir Ihnen aufeinander abgestimmte Gesamtlösungen. Wärmerückgewinnung ist dabei auch in der Gastronomie wirtschaftlich sinnvoll — besonders bei langen Betriebszeiten.', 'scanpro-child' ) . '</p>
  <p>' . __( 'Unsere Fachkompetenz und die Produkttiefe unserer Partner EXHAUSTO, exodraft und Aldes ermöglichen es uns, individuelle Konzepte für Restaurant, Bar, Betriebskantine oder Hotelküche zu entwickeln. Wir unterstützen Sie von der Planung bis zur Inbetriebnahme.', 'scanpro-child' ) . '</p>
</div>

<div class="eb-specs-grid">
  <div class="eb-spec-card">
    <h4>' . __( 'Volumenstrom', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Aussenluftvolumenstrom > 25 m³/h pro Person im Gastraum', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Schall', 'scanpro-child' ) . '</h4>
    <p>' . __( '≤ 60 dB(A) Küche / ≤ 50 dB(A) Gastraum', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Energieeffizienz', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Wärmerückgewinnung empfohlen — wirtschaftlich ab 8h Betrieb/Tag', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Filter', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Fettfilter in der Küche, Aussenluftfilter ePM1 50 % im Gastraum', 'scanpro-child' ) . '</p>
  </div>
  <div class="eb-spec-card">
    <h4>' . __( 'Regelung', 'scanpro-child' ) . '</h4>
    <p>' . __( 'Bedarfsgerechte Steuerung nach CO₂, Personenzahl und Betriebszeiten', 'scanpro-child' ) . '</p>
  </div>
</div>';

        $html = isset( $contents[ $slug ] ) ? $contents[ $slug ] : '<p>' . __( 'Inhalt folgt in Kürze.', 'scanpro-child' ) . '</p>';

        return '<div class="eb-content">' . $html . '</div>';
    }
}

// Lista curada de produtos por Einsatzbereich — cada item é resolvido no
// template (page-einsatzbereich-single.php) por nome de produto (busca no WooCommerce)
if ( ! function_exists( 'scanpro_get_einsatzbereich_products' ) ) {
    function scanpro_get_einsatzbereich_products( string $slug ): array {

        $products = [];

        $products['wohnen'] = [
            [ 'type' => 'product', 'name' => 'CX3000' ],
            [ 'type' => 'product', 'name' => 'VEX100 CF' ],
            [ 'type' => 'product', 'name' => 'VEX300' ],
            [ 'type' => 'product', 'name' => 'InspirAIR Top' ],
        ];

        $products['gewerbe'] = [
            [ 'type' => 'product', 'name' => 'CX3000' ],
            [ 'type' => 'product', 'name' => 'VEX4000' ],
            [ 'type' => 'product', 'name' => 'VEX1000RS' ],
            [ 'type' => 'product', 'name' => 'VEX1000RT' ],
            [ 'type' => 'product', 'name' => 'VEX100' ],
            [ 'type' => 'product', 'name' => 'VEX300' ],
            [ 'type' => 'product', 'name' => 'InspirAIR Top' ],
        ];

        $products['industrie'] = [
            [ 'type' => 'product', 'name' => 'VEX4000' ],
            [ 'type' => 'product', 'name' => 'VEX1000RS' ],
            [ 'type' => 'product', 'name' => 'VEX1000RT' ],
            [ 'type' => 'product', 'name' => 'Inline-Ventilator' ],
            [ 'type' => 'product', 'name' => 'Safe Plate' ],
            [ 'type' => 'product', 'name' => 'Basic Plate' ],
            [ 'type' => 'product', 'name' => 'Bypassklappe' ],
            [ 'type' => 'product', 'name' => 'BESB' ],
            [ 'type' => 'product', 'name' => 'BESF' ],
            [ 'type' => 'product', 'name' => 'DTH' ],
        ];

        $products['bildungseinrichtungen'] = [
            [ 'type' => 'product', 'name' => 'DEX3000' ],
            [ 'type' => 'product', 'name' => 'CX3000' ],
            [ 'type' => 'product', 'name' => 'VEX1000RS' ],
            [ 'type' => 'product', 'name' => 'VEX4000' ],
        ];

        $products['gastronomie'] = [
            [ 'type' => 'product', 'name' => 'VEX100' ],
            [ 'type' => 'product', 'name' => 'CX3000' ],
            [ 'type' => 'product', 'name' => 'VEX300' ],
            [ 'type' => 'product', 'name' => 'RSHT' ],
            [ 'type' => 'product', 'name' => 'RSV' ],
            [ 'type' => 'product', 'name' => 'BESB' ],
        ];

        return $products[ $slug ] ?? [];
    }
}

/* =========================================================
 * GEO / AEO — robots.txt e llms.txt virtuais
 *
 * Ambos são gerados pelo WordPress (não são ficheiros físicos).
 * Se existir um robots.txt real na raiz do site, ele tem prioridade
 * e as regras abaixo deixam de ser servidas.
 * ========================================================= */

// Agentes de IA/busca generativa que devem poder indexar o site.
if ( ! function_exists( 'scanpro_ai_user_agents' ) ) {
    function scanpro_ai_user_agents() {
        return [
            'GPTBot', 'OAI-SearchBot', 'ChatGPT-User',
            'ClaudeBot', 'Claude-User', 'Claude-SearchBot',
            'PerplexityBot', 'Perplexity-User',
            'Google-Extended', 'Applebot-Extended',
            'Amazonbot', 'meta-externalagent', 'Bytespider', 'CCBot',
        ];
    }
}

// Caminhos transacionais/privados que nenhum crawler deve rastrear.
if ( ! function_exists( 'scanpro_robots_disallow_paths' ) ) {
    function scanpro_robots_disallow_paths() {
        $paths = [ '/wp-admin/' ];

        // Carrinho, checkout e conta do cliente (slugs reais do WooCommerce)
        if ( function_exists( 'wc_get_page_id' ) ) {
            foreach ( [ 'cart', 'checkout', 'myaccount' ] as $wc_page ) {
                $page_id = wc_get_page_id( $wc_page );
                if ( $page_id > 0 ) {
                    $path = wp_make_link_relative( get_permalink( $page_id ) );
                    if ( $path && '/' !== $path ) {
                        $paths[] = trailingslashit( $path );
                    }
                }
            }
        }

        return array_unique( $paths );
    }
}

add_filter( 'robots_txt', function ( $output, $public ) {

    // Site marcado como não público: manter o bloqueio do WordPress.
    if ( ! $public ) {
        return $output;
    }

    $disallow = scanpro_robots_disallow_paths();

    $rules  = "\n# --- Scan-Pro ---\n";
    $rules .= "User-agent: *\n";
    $rules .= "Allow: /wp-admin/admin-ajax.php\n";
    foreach ( $disallow as $path ) {
        $rules .= 'Disallow: ' . $path . "\n";
    }
    $rules .= "Disallow: /*?s=\n";
    $rules .= "Disallow: /*?add-to-cart=\n";
    $rules .= "Disallow: /*?orderby=\n";
    $rules .= "Allow: /wp-content/uploads/\n";

    // Crawlers de IA: grupo próprio, senão herdariam apenas o grupo "*".
    $rules .= "\n# Generative engines\n";
    foreach ( scanpro_ai_user_agents() as $agent ) {
        $rules .= 'User-agent: ' . $agent . "\n";
    }
    $rules .= "Allow: /\n";
    foreach ( $disallow as $path ) {
        $rules .= 'Disallow: ' . $path . "\n";
    }

    $rules .= "\n# LLM-freundliche Übersicht\n";
    $rules .= '# ' . esc_url_raw( home_url( '/llms.txt' ) ) . "\n";

    return $output . $rules;
}, 10, 2 );

// Rota virtual para /llms.txt
add_action( 'init', function () {
    add_rewrite_rule( '^llms\.txt$', 'index.php?scanpro_llms=1', 'top' );

    // Regrava as rewrite rules uma única vez após alterar o tema.
    if ( get_option( 'scanpro_rewrite_version' ) !== '1' ) {
        flush_rewrite_rules( false );
        update_option( 'scanpro_rewrite_version', '1' );
    }
} );

add_filter( 'query_vars', function ( $vars ) {
    $vars[] = 'scanpro_llms';
    return $vars;
} );

add_action( 'template_redirect', function () {
    if ( ! get_query_var( 'scanpro_llms' ) ) {
        return;
    }

    $content = get_transient( 'scanpro_llms_txt' );
    if ( false === $content ) {
        $content = scanpro_build_llms_txt();
        set_transient( 'scanpro_llms_txt', $content, DAY_IN_SECONDS );
    }

    header( 'Content-Type: text/plain; charset=utf-8' );
    header( 'X-Robots-Tag: all' );
    echo $content; // phpcs:ignore WordPress.Security.EscapeOutput — texto puro já montado
    exit;
} );

// Invalida o cache do llms.txt quando o conteúdo muda.
add_action( 'save_post', function () { delete_transient( 'scanpro_llms_txt' ); } );
add_action( 'edited_term', function () { delete_transient( 'scanpro_llms_txt' ); } );

// Normaliza um texto para uma linha curta de descrição.
if ( ! function_exists( 'scanpro_llms_summary' ) ) {
    function scanpro_llms_summary( $text ) {
        $text = wp_strip_all_tags( strip_shortcodes( (string) $text ), true );
        $text = trim( preg_replace( '/\s+/u', ' ', $text ) );
        return $text ? wp_trim_words( $text, 30, '…' ) : '';
    }
}

// Monta o conteúdo do /llms.txt a partir do conteúdo real do site.
if ( ! function_exists( 'scanpro_build_llms_txt' ) ) {
    function scanpro_build_llms_txt() {

        $name = get_bloginfo( 'name' ) ?: 'Scan-Pro AG';
        $out  = '# ' . $name . "\n\n";

        $out .= '> ' . __( 'Scan-Pro AG ist der Schweizer Spezialist für Lüftungstechnik und Wärmerückgewinnung: Planung, Lieferung, Montage und Service von Lüftungsanlagen für Wohnen, Gewerbe, Industrie, Bildungseinrichtungen und Gastronomie.', 'scanpro-child' ) . "\n\n";

        $out .= __( 'Über 50 Jahre Erfahrung (seit 1975). Standort: Bahnhofstrasse 1, CH-8852 Altendorf, Schweiz. Telefon: +41 43 355 34 00. E-Mail: info@scanpro.ch. Inhaltssprache: Deutsch.', 'scanpro-child' ) . "\n";

        // --- Hauptseiten ---
        $pages = [
            'ueber-uns'      => __( 'Unternehmen, Geschichte und Kompetenzen seit 1975', 'scanpro-child' ),
            'team'           => __( 'Ansprechpartner und Fachpersonal', 'scanpro-child' ),
            'einsatzbereiche'=> __( 'Übersicht der Anwendungsbereiche für Lüftungslösungen', 'scanpro-child' ),
            'referenzen'     => __( 'Realisierte Projekte und Referenzanlagen', 'scanpro-child' ),
            'wissen'         => __( 'Fachwissen zu Lüftung, CO₂, Normen und Regelungstechnik', 'scanpro-child' ),
            'kontakt'        => __( 'Kontaktformular, Adresse und Anfahrt', 'scanpro-child' ),
        ];

        $out .= "\n## " . __( 'Hauptseiten', 'scanpro-child' ) . "\n\n";
        $out .= '- [' . __( 'Startseite', 'scanpro-child' ) . '](' . home_url( '/' ) . '): '
              . __( 'Intelligente Lüftungslösungen und Wärmerückgewinnung', 'scanpro-child' ) . "\n";

        foreach ( $pages as $slug => $desc ) {
            $page  = get_page_by_path( $slug );
            $title = $page ? get_the_title( $page ) : ucfirst( $slug );
            $out  .= '- [' . $title . '](' . home_url( '/' . $slug ) . '): ' . $desc . "\n";
        }

        // --- Einsatzbereiche ---
        $areas = [
            'wohnen'                => __( 'Komfortlüftung und Wärmerückgewinnung für Wohnbauten', 'scanpro-child' ),
            'gewerbe'               => __( 'Lüftungslösungen für Büro-, Verkaufs- und Gewerbeflächen', 'scanpro-child' ),
            'industrie'             => __( 'Prozess- und Hallenlüftung für industrielle Anwendungen', 'scanpro-child' ),
            'bildungseinrichtungen' => __( 'Schul- und Klassenzimmerlüftung mit CO₂-Regelung', 'scanpro-child' ),
            'gastronomie'           => __( 'Küchen- und Gastronomielüftung', 'scanpro-child' ),
        ];

        $out .= "\n## " . __( 'Einsatzbereiche', 'scanpro-child' ) . "\n\n";
        foreach ( $areas as $slug => $desc ) {
            $out .= '- [' . ucfirst( str_replace( '-', ' ', $slug ) ) . '](' . home_url( '/einsatzbereiche/' . $slug ) . '): ' . $desc . "\n";
        }

        // --- Produktkategorien (WooCommerce) ---
        if ( taxonomy_exists( 'product_cat' ) ) {
            $parent = get_term_by( 'slug', 'produkte', 'product_cat' );
            $cats   = $parent
                ? get_terms( [ 'taxonomy' => 'product_cat', 'parent' => $parent->term_id, 'hide_empty' => true, 'orderby' => 'menu_order', 'order' => 'ASC' ] )
                : [];

            if ( ! empty( $cats ) && ! is_wp_error( $cats ) ) {
                $out .= "\n## " . __( 'Produktkategorien', 'scanpro-child' ) . "\n\n";
                foreach ( $cats as $cat ) {
                    $link = get_term_link( $cat );
                    if ( is_wp_error( $link ) ) {
                        continue;
                    }
                    $desc = scanpro_llms_summary( $cat->description );
                    $out .= '- [' . $cat->name . '](' . $link . ')' . ( $desc ? ': ' . $desc : '' ) . "\n";

                    $subs = get_terms( [ 'taxonomy' => 'product_cat', 'parent' => $cat->term_id, 'hide_empty' => true, 'orderby' => 'menu_order', 'order' => 'ASC' ] );
                    if ( ! empty( $subs ) && ! is_wp_error( $subs ) ) {
                        foreach ( $subs as $sub ) {
                            $sub_link = get_term_link( $sub );
                            if ( is_wp_error( $sub_link ) ) {
                                continue;
                            }
                            $out .= '  - [' . $sub->name . '](' . $sub_link . ")\n";
                        }
                    }
                }
            }
        }

        // --- Produkte ---
        if ( post_type_exists( 'product' ) ) {
            $products = get_posts( [
                'post_type'        => 'product',
                'post_status'      => 'publish',
                'numberposts'      => 300,
                'orderby'          => 'title',
                'order'            => 'ASC',
                'suppress_filters' => false,
            ] );

            if ( $products ) {
                $out .= "\n## " . __( 'Produkte', 'scanpro-child' ) . "\n\n";
                foreach ( $products as $product ) {
                    $desc = scanpro_llms_summary( $product->post_excerpt ?: $product->post_content );
                    $out .= '- [' . get_the_title( $product ) . '](' . get_permalink( $product ) . ')'
                          . ( $desc ? ': ' . $desc : '' ) . "\n";
                }
            }
        }

        // --- Wissen ---
        $knowledge = [
            'wissen/co2'                     => __( 'CO₂-Konzentration, Luftqualität und Grenzwerte', 'scanpro-child' ),
            'wissen/faq'                     => __( 'Häufige Fragen zu Lüftung und Wärmerückgewinnung', 'scanpro-child' ),
            'wissen/blog'                    => __( 'Fachbeiträge und Neuigkeiten', 'scanpro-child' ),
            'wissen/regulierungen'           => __( 'Normen und Vorschriften für Lüftungsanlagen in der Schweiz', 'scanpro-child' ),
            'wissen/regelung-von-luftmengen' => __( 'Regelung von Luftmengen und Volumenstromregelung', 'scanpro-child' ),
        ];

        $out .= "\n## " . __( 'Wissen', 'scanpro-child' ) . "\n\n";
        foreach ( $knowledge as $path => $desc ) {
            $label = ucfirst( str_replace( [ 'wissen/', '-' ], [ '', ' ' ], $path ) );
            $out  .= '- [' . $label . '](' . home_url( '/' . $path ) . '): ' . $desc . "\n";
        }

        // --- Blogbeiträge recentes ---
        $posts = get_posts( [ 'numberposts' => 20, 'post_status' => 'publish' ] );
        if ( $posts ) {
            $out .= "\n## " . __( 'Aktuelle Beiträge', 'scanpro-child' ) . "\n\n";
            foreach ( $posts as $post ) {
                $desc = scanpro_llms_summary( $post->post_excerpt ?: $post->post_content );
                $out .= '- [' . get_the_title( $post ) . '](' . get_permalink( $post ) . ')'
                      . ( $desc ? ': ' . $desc : '' ) . "\n";
            }
        }

        // --- Kontakt ---
        $out .= "\n## " . __( 'Kontakt', 'scanpro-child' ) . "\n\n";
        $out .= '- ' . __( 'Adresse', 'scanpro-child' ) . ": Scan-Pro AG, Bahnhofstrasse 1, CH-8852 Altendorf, Schweiz\n";
        $out .= '- ' . __( 'Telefon', 'scanpro-child' ) . ": +41 43 355 34 00\n";
        $out .= "- E-Mail: info@scanpro.ch\n";
        $out .= '- ' . __( 'Kontaktformular', 'scanpro-child' ) . ': ' . home_url( '/kontakt' ) . "\n";

        // --- Optional ---
        $out .= "\n## Optional\n\n";
        $out .= '- [Impressum](' . home_url( '/impressum' ) . ")\n";
        $out .= '- [' . __( 'Datenschutz', 'scanpro-child' ) . '](' . home_url( '/datenschutz' ) . ")\n";
        $out .= '- [Sitemap](' . home_url( '/wp-sitemap.xml' ) . ")\n";

        return $out;
    }
}

/* =========================================================
 * E-Mail-Versand (Kontaktformular)
 *
 * Ohne From-Header verschickt WordPress als wordpress@<domain>.
 * Diese Adresse existiert als Postfach nicht und wird von vielen
 * Mailservern (u. a. Hostinger) abgewiesen — wp_mail() gibt dann
 * false zurück und das Formular zeigt eine Fehlermeldung.
 * ========================================================= */

add_filter( 'wp_mail_from', function ( $from ) {
    // Apenas substitui o remetente padrão; não mexe no que plugins definirem.
    return ( 0 === strpos( (string) $from, 'wordpress@' ) ) ? 'info@scanpro.ch' : $from;
} );

add_filter( 'wp_mail_from_name', function ( $from_name ) {
    return ( 'WordPress' === $from_name ) ? 'Scan-Pro Website' : $from_name;
} );

// Regista o motivo real da falha no error_log do servidor.
add_action( 'wp_mail_failed', function ( $error ) {
    if ( is_wp_error( $error ) ) {
        error_log( '[Scan Pro] wp_mail fehlgeschlagen: ' . $error->get_error_message() );
    }
} );

/* =========================================================
 * Web3Forms — Kontaktformular
 *
 * Access Key aus dem Web3Forms-Dashboard hier eintragen.
 * Alternativ per Filter 'scanpro_web3forms_key' setzen.
 * ========================================================= */

if ( ! defined( 'SCANPRO_WEB3FORMS_KEY' ) ) {
    define( 'SCANPRO_WEB3FORMS_KEY', '10c92099-14a6-40d2-b3ce-060491a4f2a0' );
}

/* =========================================================
 * Übersetzungen aus der .mo-Datei lesen, nicht aus .l10n.php
 *
 * Seit WordPress 6.5 werden Übersetzungen bevorzugt aus einer
 * PHP-Datei (.l10n.php) geladen. Auf diesem Server ist OPcache aktiv:
 * eine einmal kompilierte PHP-Datei bleibt im Speicher, auch nachdem
 * Loco sie neu geschrieben hat. Folge: die erste Übersetzung erscheint,
 * jede weitere Änderung nicht mehr.
 *
 * Die .mo-Datei ist eine reine Datendatei und wird bei jeder Änderung
 * neu gelesen — damit wirken Änderungen sofort.
 * ========================================================= */
add_filter( 'translation_file_format', function () {
    return 'mo';
} );
